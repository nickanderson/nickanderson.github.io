---
title: HP Support Fail
author: Nick Anderson
type: post
date: 2010-01-15T20:12:55+00:00
url: /2010/01/15/hp-support-fail/
syntaxhighlighter_encoded:
  - 1
categories:
  - Posts
tags:
  - fail

---
From time to time  I have not so pleasant support experiences. Today I had another.<!--more-->

> [Friday, January 15, 2010 1:37 PM] &#8212; Automatically generated message:
  
> This is an automated message. Your request has been received by the Technical Support Center and has been queued until a support analyst is available. Support for HP and Compaq desktops and Workstations is available 24 hours a day, 7 days a week. You will receive a response to your support request in 5 minutes or less.

> <table border="0" width="100%">
>   <tr>
>     <td width="100%" bgcolor="#808080">
>
>     </td>
>   </tr>
> </table>
> 
> [Friday, January 15, 2010 1:37 PM] &#8212; Automatically generated message:
  
> For reference, your Case ID is 4609222889
> 
> <table border="0" width="100%">
>   <tr>
>     <td width="100%" bgcolor="#808080">
>
>     </td>
>   </tr>
> </table>
> 
> [Friday, January 15, 2010 1:47 PM] &#8212; Nick Anderson says:
  
> hello?
> 
> <table border="0" width="100%">
>   <tr>
>     <td width="100%" bgcolor="#808080">
>
>     </td>
>   </tr>
> </table>
> 
> [Friday, January 15, 2010 1:58 PM] &#8212; Nick Anderson says:
  
> hello?
> 
> <table border="0" width="100%">
>   <tr>
>     <td width="100%" bgcolor="#808080">
>
>     </td>
>   </tr>
> </table>
> 
> [Friday, January 15, 2010 1:58 PM] &#8212; Nick Anderson says:
  
> this is a reallly long 5 minutes
> 
> <table border="0" width="100%">
>   <tr>
>     <td width="100%" bgcolor="#808080">
>
>     </td>
>   </tr>
> </table>
> 
> [Friday, January 15, 2010 2:02 PM] &#8212; Nick Anderson says:
  
> Well you see, my USB ports have started to fail.
> 
> <table border="0" width="100%">
>   <tr>
>     <td width="100%" bgcolor="#808080">
>
>     </td>
>   </tr>
> </table>
> 
> [Friday, January 15, 2010 2:02 PM] &#8212; Nick Anderson says:
  
> This started about 2 weeks ago.
> 
> <table border="0" width="100%">
>   <tr>
>     <td width="100%" bgcolor="#808080">
>
>     </td>
>   </tr>
> </table>
> 
> [Friday, January 15, 2010 2:03 PM] &#8212; Nick Anderson says:
  
> As they failed I moved my devices to ports that worked and chained through a USB hub.
> 
> <table border="0" width="100%">
>   <tr>
>     <td width="100%" bgcolor="#808080">
>
>     </td>
>   </tr>
> </table>
> 
> [Friday, January 15, 2010 2:03 PM] &#8212; Nick Anderson says:
  
> Today the last USB port failed. I need to have the motherboard replaced.
> 
> <table border="0" width="100%">
>   <tr>
>     <td width="100%" bgcolor="#808080">
>
>     </td>
>   </tr>
> </table>
> 
> [Friday, January 15, 2010 2:04 PM] &#8212; Nick Anderson says:
  
> Since no one wants to respond to me, I will post this chat transcript on my blog.
> 
> <table border="0" width="100%">
>   <tr>
>     <td width="100%" bgcolor="#808080">
>
>     </td>
>   </tr>
> </table>
> 
> [Friday, January 15, 2010 2:08 PM] &#8212; Nick Anderson says:
  
> <a href="http://www.cmdln.org/2010/01/15/hp-support-fail" target="_blank">http://www.cmdln.org/2010/01/15/hp-support-fail</a>
> 
> <table border="0" width="100%">
>
> </table>