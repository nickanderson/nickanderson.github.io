---
title: Centos not going anywhere stop spreading the FUD
author: Nick Anderson
type: post
date: 2009-08-01T09:43:01+00:00
url: /2009/08/01/centos-not-going-anywhere-stop-spreading-the-fud/
syntaxhighlighter_encoded:
  - 1
categories:
  - Posts
tags:
  - FUD

---
I&#8217;m sure you have heard about the open letter from Centos regarding not having control of some key elements of the project and the AWOL admin. I purposely did not comment on this because I did not want to spread any FUD. Centos is a huge project, I had no doubt that things would get rectified in a timely manner.

Here is the latest

> The CentOS Development team had a routine meeting today with Lance Davis in attendance. During the meeting a majority of issues were resolved immediately and a working agreement was reached with deadlines for remaining unresolved issues. There should be no impact to any CentOS users going forward.
> 
> The CentOS project is now in control of the CentOS.org and CentOS.info domains and owns all trademarks, materials, and artwork in the CentOS distributions.
> 
> We look forward to working with Lance to quickly complete all the agreed upon issues.
> 
> More information will follow soon.
> 
> <a href="http://www.centos.org/modules/news/article.php?storyid=381" target="_blank">Original Letter</a>
> 
> Last Update: August 1, 2009 04:34 UTC by Donavan Nelson

Sourced from [centos.org][1] Aug 1, 2009 4:00 am CST

 [1]: http://www.centos.org