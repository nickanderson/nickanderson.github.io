---
title: SyntaxHighlighter Plus Patch
author: Nick Anderson
type: post
date: 2008-04-07T06:04:59+00:00
url: /2008/04/07/syntaxhighlighter-plus-patch/
categories:
  - Posts
tags:
  - bash
  - code
  - contribution
  - highlight
  - open source
  - patch
  - syntax
  - syntaxhighlighter plus

---
Disclaimer: I did not write the bash support for [syntaxhighlighter][1] bboy.mr.freeze did and it can also be found [here][2] . All I did was take that, and modify [SyntaxHighlighter Plus][3] to take advantage of it.<!--more-->

<!--adsense-->

I have provided the files here as an alternate mirror in case that shBrushBash.js disappears or if SyntaxHighlighter Plus does not incorporate the patch for others.

[syntaxhighlighter-plus-cmdlnorg_bashtar][4]

 [1]: http://code.google.com/p/syntaxhighlighter/ "syntaxhighlighter"
 [2]: http://bboy.mr.freeze.googlepages.com/shBrushBash.js
 [3]: http://thislab.com/2007/12/16/release-wordpress-plugin-syntaxhighlighter-plus/
 [4]: http://www.cmdln.org/wp-content/uploads/2008/04/syntaxhighlighter-plus-cmdlnorg_bashtar.gz