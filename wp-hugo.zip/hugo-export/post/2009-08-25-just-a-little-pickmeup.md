---
title: Just a little pickmeup
author: Nick Anderson
type: post
date: 2009-08-25T22:47:56+00:00
url: /2009/08/25/just-a-little-pickmeup/
syntaxhighlighter_encoded:
  - 1
enclosure:
  - |
    |
        http://www-03.ibm.com/ibm/history/exhibits/music/wav/100percent.wav
        1256030
        audio/x-wav
        
  - |
    |
        http://www-03.ibm.com/ibm/history/exhibits/music/wav/hailtoibm.wav
        2678850
        audio/x-wav
        
  - |
    |
        http://www-03.ibm.com/ibm/history/exhibits/music/wav/marchon.wav
        3376788
        audio/x-wav
        
  - |
    |
        http://www-03.ibm.com/ibm/history/exhibits/music/wav/everonward.wav
        1535326
        audio/x-wav
        
categories:
  - Posts
tags:
  - funny

---
Wow I can&#8217;t believe these never made the top 40!

[IBM One Hundred Percent Club][1]

[IBM anthem][2]

[March On With IBM][3]

[IBM rally song][4]

Inspired by <a href=http://www.cuddletech.com/blog/>Ben Rockwoods comment today about the IBM Songbook</a>

 [1]: http://www-03.ibm.com/ibm/history/exhibits/music/wav/100percent.wav
 [2]: http://www-03.ibm.com/ibm/history/exhibits/music/wav/hailtoibm.wav
 [3]: http://www-03.ibm.com/ibm/history/exhibits/music/wav/marchon.wav
 [4]: http://www-03.ibm.com/ibm/history/exhibits/music/wav/everonward.wav