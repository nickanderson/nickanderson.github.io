---
title: Now Mobile Ready
author: Nick Anderson
type: post
date: 2010-01-27T14:46:29+00:00
url: /2010/01/27/now-mobile-ready/
syntaxhighlighter_encoded:
  - 1
categories:
  - Posts
tags:
  - shoutout

---
I&#8217;d like to thank ﻿﻿﻿[Dale Mugford][1] and [Duane Storey][2] from [BraveNewCode][3] for the nice WordPress plugin and bundled mobile theme. If you visit my site on your mobile device you should get a slimmed down page, let me know what ya think.

 [1]: http://www.dalemugford.com/
 [2]: http://www.duanestorey.com/
 [3]: http://www.bravenewcode.com