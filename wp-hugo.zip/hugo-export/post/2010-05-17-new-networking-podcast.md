---
title: New Networking Podcast
author: Nick Anderson
type: post
date: 2010-05-17T15:29:06+00:00
url: /2010/05/17/new-networking-podcast/
aktt_tweeted:
  - 1
categories:
  - Posts
tags:
  - networking
  - podcast
  - sysadmin

---
They are only on their 3rd episode, but its been good listening so far. If your into networking check it out.  [http://packetpushers.net/][1]

 [1]: http://packetpushers.net