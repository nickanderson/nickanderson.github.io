---
title: Top for MySQL with mytop
author: Nick Anderson
type: post
date: 2008-12-06T07:57:12+00:00
url: /2008/12/06/top-for-mysql-with-mytop/
aktt_notify_twitter:
  - no
categories:
  - Posts
tags:
  - monitoring
  - mysql

---
I see <a rel="external nofollow" href="http://dancingpenguinsoflight.com/">Samuel Huckins</a> just had a post about apachetop [http://dancingpenguinsoflight.com/2008/12/top-for-apache-activity/][1] which I have been meaning to mention for a while, but being that there is a fresh post about it I will mention Mytop instead.

Mytop is top for mysql. It can be used for monitoring the threads and overall performance of a MySQL.

Its an easy install in debain with a quick aptitude install mytop.

Here is some example output (sorry my mysql server isnt very busy atm).

[<img class="aligncenter size-full wp-image-169" title="mytop" src="http://www.cmdln.org/wp-content/uploads/2008/12/mytop.png" alt="" width="500" height="174" srcset="http://www.cmdln.org/wp-content/uploads/2008/12/mytop.png 977w, http://www.cmdln.org/wp-content/uploads/2008/12/mytop-300x104.png 300w" sizes="(max-width: 500px) 100vw, 500px" />][2]

 [1]: http://dancingpenguinsoflight.com/2008/12/top-for-apache-activity/ "http://dancingpenguinsoflight.com/2008/12/top-for-apache-activity/"
 [2]: http://www.cmdln.org/wp-content/uploads/2008/12/mytop.png