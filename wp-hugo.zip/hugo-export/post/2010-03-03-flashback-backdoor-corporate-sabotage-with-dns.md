---
title: 'Flashback: Backdoor Corporate Sabotage With DNS'
author: Nick Anderson
type: post
date: 2010-03-03T14:31:37+00:00
url: /2010/03/03/flashback-backdoor-corporate-sabotage-with-dns/
syntaxhighlighter_encoded:
  - 1
has_been_twittered:
  - yes
categories:
  - Posts
tags:
  - dns
  - flashback
  - hacking

---
This is just an old entry that I thought was interesting, and it appears its still relevant. Like a broken record, &#8220;economic times are rough&#8221;, what better way to boost your revenue than to exploit your customers. What better way to suppress a competitor than to increase a competitors infrastructure costs (with little visibility to boot). I did some repeated lookups this morning and got similar results.

[Backdoor Corporate Sabotage With DNS][1]

 [1]: http://www.cmdln.org/2008/07/09/backdoor-corporate-sabotage-with-dns/