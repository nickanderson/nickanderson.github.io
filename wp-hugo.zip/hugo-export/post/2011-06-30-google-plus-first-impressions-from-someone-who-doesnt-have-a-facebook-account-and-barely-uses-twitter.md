---
title: 'Google plus: first impressions from someone who doesnt have a facebook account and barely uses twitter'
author: Nick Anderson
type: post
date: 2011-07-01T04:03:34+00:00
url: /2011/06/30/google-plus-first-impressions-from-someone-who-doesnt-have-a-facebook-account-and-barely-uses-twitter/
openid_comments:
  - 'a:2:{i:0;s:4:"1152";i:1;s:4:"1153";}'
categories:
  - Posts

---
Today I spent some time checking out [google plus][1]. If you haven&#8217;t heard about it by now you probably live under a rock. Google plus is googles latest push into the social networking scene. I&#8217;ve never been real hip on the social networking scene. 

I have a twitter account @cmdln_ but I rarely actually follow the people I am following. The signal to noise ratio is just so high. And beyond that its information overload and trying to catch up on someone elses conversation seems cumbersome and annoying.

I&#8217;m proud to say I don&#8217;t have a facebook account and never had one. My wife does and she can keep me up to date on any news. Beyond that usually when I want to talk to one of my friends I send them an instant message, shoot them an email, pick up the phone, send a txt message, or drop by in person. I really don&#8217;t feel like I am missing out on anything.

Now my thoughts on google plus. WOW. I&#8217;m really amazed at how well it is done. The pieces seem to integrate well, Windows, Mac, and Linux support in their video chat &#8220;Hangout&#8221;. Nothing feels overwhelming. I see Hangout being great for meetings. Circles is a great way to share information, it seems to solve the issues that I have always wondered about with facebook. Like I said, I don&#8217;t have an account but some of the one-liners my wife repeats makes me wonder if anyone realizes who can see what they post. Well see what is to come, but to me what google has here is interesting.

 [1]: http://plus.google.com