---
title: 'Flashback: Trust not DNS or How to properly move a website'
author: Nick Anderson
type: post
date: 2010-03-02T05:01:58+00:00
url: /2010/03/01/flashback-trust-not-dns-or-how-to-properly-move-a-website/
syntaxhighlighter_encoded:
  - 1
has_been_twittered:
  - yes
categories:
  - Posts
tags:
  - dns
  - flashback
  - reverse proxy

---
[Matt Simmons][1] is trying to dust off some old articles he think some people may have missed. So I figure why not. A while back I talked about how to move a website (read DNS sucks , you need a reverse proxy). In fact I have talked about reverse proxies a few times since I tend to find them so useful. At any rate, this article stemmed from the first hand experience that opened my eyes to how bad DNS infrastructure really was.

[[Matt Simmons][1] is trying to dust off some old articles he think some people may have missed. So I figure why not. A while back I talked about how to move a website (read DNS sucks , you need a reverse proxy). In fact I have talked about reverse proxies a few times since I tend to find them so useful. At any rate, this article stemmed from the first hand experience that opened my eyes to how bad DNS infrastructure really was.

][2]

 [1]: http://www.standalone-sysadmin.com/blog/
 [2]: http://www.cmdln.org/2008/11/01/trust-not-dns-or-how-to-properly-move-a-website/