---
title: Rsync for Windows clients
author: Nick Anderson
type: post
date: 2009-08-28T14:19:14+00:00
url: /2009/08/28/rsync-for-windows-clients/
syntaxhighlighter_encoded:
  - 1
categories:
  - Posts
tags:
  - backup
  - rsync
  - windows

---
It looks like I will need a windows backup solution for a small project soon. As you probably know I don&#8217;t typically do Windows so I am reaching out. I typically use rsync for most of my backup needs. To be more specific I like to use rsnapshot which is a wrapper around rsync. Have you ever wanted rsync on windows? What did you use.

I am aware of several options.

There is of course cygwin. Beyond cygwin it seems nasbackup (http://www.nasbackup.com) and deltacopy (http://www.aboutmyip.com/AboutMyXApp/DeltaCopy.jsp) were the best options I could find.

Do you have any suggestions? What other solutions for windows backup have you used. I don&#8217;t have a specific reason but I just cringe at the thought of using windows internal backup mechanism.