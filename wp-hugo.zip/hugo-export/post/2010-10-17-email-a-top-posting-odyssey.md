---
title: Email, a top posting odyssey
author: Nick Anderson
type: post
date: 2010-10-17T15:40:27+00:00
url: /2010/10/17/email-a-top-posting-odyssey/
categories:
  - Posts

---
﻿An odyssey of a typical email thread using the top posting style that most email clients default to these days. 

<pre class="brush: plain; title: ; notranslate" title="">Subject: Provide Satan VPN access
To: Frank, Jane, Bill, Zoe, John, Matt

I'm not sure. Nick, do you have any ideas?

-Franky

On Fri, Oct 15, 2010 at 2:20 PM, Jane wrote:
&gt;
&gt; Great idea!.
&gt;
&gt; - Jane
&gt; "Jannies got a gun"
&gt;
&gt; On Fri, Oct 15, 2010 at 2:15 PM, Frank wrote:
&gt;&gt;
&gt;&gt; Oh, I dont know. I think we should ask somone else. I'll email Nick,
&gt;&gt; give
&gt;&gt; him no context, asking to decipher our previous conversation
&gt;&gt; backwards, and
&gt;&gt; ask for an answer.
&gt;&gt;
&gt;&gt; - Franky
&gt;&gt;
&gt;&gt;&gt; On Fri, Oct 15, 2010 at 2:00 PM, Zoe wrote:
&gt;&gt;&gt;
&gt;&gt;&gt; Thanks Bill!
&gt;&gt;&gt;
&gt;&gt;&gt; - Zoe
&gt;&gt;&gt;
&gt;&gt;&gt;&gt; On Fri, Oct 15, 2010 at 1:53 PM, Bill wrote:
&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt; Hey Zoe,
&gt;&gt;&gt;&gt; I heard you had your baby! Thats great! I saw all the pictures on
&gt;&gt;&gt;&gt; facebook
&gt;&gt;&gt;&gt; What a cutie! You will have to keep a close eye on her when she
&gt;&gt;&gt;&gt; gets
&gt;&gt;&gt;&gt; older!
&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt; - Bill Bong
&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt; On Fri, Oct 15, 2010 at 1:30 PM, Matt wrote:
&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt; I will be out of the office Friday Oct 15 between 1:29 PM and 1:31
&gt;&gt;&gt;&gt;&gt; PM for
&gt;&gt;&gt;&gt;&gt; a potty break.
&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt; - Matt
&gt;&gt;&gt;&gt;&gt; MCSE
&gt;&gt;&gt;&gt;&gt; RHCE
&gt;&gt;&gt;&gt;&gt; Minister ULC
&gt;&gt;&gt;&gt;&gt; Certified Vet Tech
&gt;&gt;&gt;&gt;&gt; Certified Matt
&gt;&gt;&gt;&gt;&gt; linkedin.com/mattsocool
&gt;&gt;&gt;&gt;&gt; 555-555-1234
&gt;&gt;&gt;&gt;&gt; matt@hotmail.com
&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt; On Fri, Oct 15, 2010 at 1:30 PM, Jane wrote:
&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt; I didn't get that last meeting invite, I
&gt;&gt;&gt;&gt;&gt;&gt; think something is busted with my calendar. When try to access
&gt;&gt;&gt;&gt;&gt;&gt; that
&gt;&gt;&gt;&gt;&gt;&gt; webserver
&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt; I get precussion defiled "/". I think my ISP is having problems
&gt;&gt;&gt;&gt;&gt;&gt; again.
&gt;&gt;&gt;&gt;&gt;&gt; I couldnt log into facebok or twiterr ethr!
&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt; - Jane
&gt;&gt;&gt;&gt;&gt;&gt; Sent from my super cool mobile device
&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt;&gt; On Fri, Oct 15, 2010 at 1:20 PM, Matt wrote:
&gt;&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt;&gt; OK I created Satan's vpn account.
&gt;&gt;&gt;&gt;&gt;&gt;&gt; username: satan
&gt;&gt;&gt;&gt;&gt;&gt;&gt; password: isevil
&gt;&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt;&gt; - Matt
&gt;&gt;&gt;&gt;&gt;&gt;&gt; MCSE
&gt;&gt;&gt;&gt;&gt;&gt;&gt; RHCE
&gt;&gt;&gt;&gt;&gt;&gt;&gt; Minister ULC
&gt;&gt;&gt;&gt;&gt;&gt;&gt; Certified Vet Tech
&gt;&gt;&gt;&gt;&gt;&gt;&gt; Certified Matt
&gt;&gt;&gt;&gt;&gt;&gt;&gt; linkedin.com/mattsocool
&gt;&gt;&gt;&gt;&gt;&gt;&gt; 555-555-1234
&gt;&gt;&gt;&gt;&gt;&gt;&gt; matt@hotmail.com
&gt;&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; On Fri, Oct 15, 2010 at 1:00 PM, John wrote:
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; Thats, not something I have access to but Matt does.
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; Adding Matt, Matt can you create this
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; account?
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; - John
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; On Fri, Oct 15, 2010 at 12:30 PM, Frank wrote:
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; John, can you create a VPN account for Satan? Jane needs to
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; run some
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; tests
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; against the
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; new demo webserver before the client demo at 12:45. I realize
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; this is
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; your lunch our but I'm hoping you can get this done before
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; then.
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; Thanks! You're a life saver.
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; On Mon, Oct 11, 2010 at 9:45 AM, Jane wrote:
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; Hey Frank, hope
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; you had a good weekend. Satan
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; needs a vpn account so
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; he can make some changes to permissions on that demo server.
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; Can you
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; create an account for
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; him? I have a
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; demo with
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; the customer
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; this
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; friday at 12:45 PM.
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; -Jane
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;
</pre>

What was it that I was supposed to have an idea on? Obviously there are several things from this fictitious email that are bothersome.

  * long signatures with superfluous information
  * credentials sent in email
  * reply all on personal notes

just to name a few.

Things can get even more frustrating as threads diverge (when multiple people reply to the same email and people reply to those emails). One of the most common reasons I hear about people preserving message history like that is to give context to later conversations. But once your thread has diverged  no email contains all of the necessary information. So you are relegated to looking through multiple sub threads looking for something that may be only in one of multiple threads or may be in each of the threads depending on when the thread diverged.

Perhaps I have never learned how to read these emails. one or two words per line as you go back further and further in an email I find exceedingly difficult to decipher.  I try not to rant about top posting too frequently, I just try to trim emails to only the specific information needed and email only those who need to be involved in a conversation.

Whats your take on top posting? Does it drive you nutty? Have you ever found a successful method to help sway users to a more polite email etiquette?