---
title: 'Flashback: Vim customization for python'
author: Nick Anderson
type: post
date: 2010-03-04T15:05:10+00:00
url: /2010/03/04/flashback-vim-customization-for-python/
syntaxhighlighter_encoded:
  - 1
categories:
  - Posts
tags:
  - flashback
  - python
  - vim

---
Python has become my language of choice for automation and general scripting. Its nice to have an editor that makes things easier when your doing things. Its also nice to use an editor that you can find just about anywhere. I have customized my vim to make doing things in python much quicker and this is an old post where I talk about some of the modifications.

<a title="Permanent Link to Vim customization for python" rel="bookmark" href="../2008/10/18/vim-customization-for-python/">Vim customization for python</a>