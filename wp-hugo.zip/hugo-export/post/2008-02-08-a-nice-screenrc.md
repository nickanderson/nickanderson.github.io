---
title: A nice .screenrc
author: Nick Anderson
type: post
date: 2008-02-08T14:04:26+00:00
url: /2008/02/08/a-nice-screenrc/
openid_comments:
  - 'a:1:{i:0;i:1285;}'
categories:
  - Posts
tags:
  - .screenrc
  - commandline
  - screen

---
Hopefully you already know about screen, its one of the best command line utilites I use. Here is a purty screenrc for you.

<a TITLE=".screenrc" HREF="http://www.cmdln.org/wp-content/uploads/2008/02/my.screenrc">.screenrc</a>