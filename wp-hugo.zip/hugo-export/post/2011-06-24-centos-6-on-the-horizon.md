---
title: Centos 6 on the horizon
author: Nick Anderson
type: post
date: 2011-06-24T17:41:30+00:00
url: /2011/06/24/centos-6-on-the-horizon/
categories:
  - Posts
tags:
  - centos
  - news
  - sysadmin

---
Just happened to notice that centos 6 looks like it will be dropping soon. In QA and syncing to internal servers today, sync to public mirrors on Monday.

http://qaweb.dev.centos.org/qa