---
title: Bibble The Best Photo Editing Software For Linux Bought By Corel
author: Nick Anderson
type: post
date: 2012-03-29T04:50:54+00:00
url: /2012/03/28/bibble-the-best-photo-editing-software-for-linux-bought-by-corel/
categories:
  - Posts
tags:
  - '#photograpy'
  - linux

---
[<img class="alignleft  wp-image-1017" title="aftershot_01" src="http://www.cmdln.org/wp-content/uploads/2012/03/aftershot_01.jpg" alt="" width="540" height="112" srcset="http://www.cmdln.org/wp-content/uploads/2012/03/aftershot_01.jpg 900w, http://www.cmdln.org/wp-content/uploads/2012/03/aftershot_01-300x62.jpg 300w" sizes="(max-width: 540px) 100vw, 540px" />][1]I have been using [bibble][2] for about a year now. Its the best photo editing software that ran on linux that I could find. It probably isn&#8217;t as polished as Photoshop but it has its own great features like threading so it can use all of your cores for rendering.

Just over a week ago I noticed it had been bought by Corel and its been re-branded to [AfterShotPro][3]. I really hope they continue to develop it and provide Linux support.

 [1]: http://www.cmdln.org/wp-content/uploads/2012/03/aftershot_01.jpg
 [2]: http://bibblelabs.com/
 [3]: http://www.corel.com/corel/product/index.jsp?pid=prod4670071&cid=catalog20038&segid=6000006