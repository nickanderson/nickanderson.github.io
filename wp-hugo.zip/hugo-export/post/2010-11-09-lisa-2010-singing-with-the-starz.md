---
title: 'LISA 2010: Singing with the Starz'
author: Nick Anderson
type: post
date: 2010-11-09T15:42:43+00:00
url: /2010/11/09/lisa-2010-singing-with-the-starz/
categories:
  - Posts
tags:
  - lisa10
  - sysadmin

---
Singing with the stars is a reality show where the famous and not so famous SysAdmins strut their stuff and show off their skillz.

Guest appearances by: Brian Atkisson, Brandi-Jvonne Mortimer, [Matt Simmons][1], [Joseph Kern][2], [Ian Paredes][3], and Nick Anderson

These are clips from the pilot show:





﻿

 [1]: http://www.standalone-sysadmin.com/blog/
 [2]: http://www.semafour.net/
 [3]: http://redbluemagenta.com/