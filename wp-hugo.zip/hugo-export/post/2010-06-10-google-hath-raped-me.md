---
title: Google hath raped me eyes
author: Nick Anderson
type: post
date: 2010-06-10T13:15:15+00:00
url: /2010/06/10/google-hath-raped-me/
categories:
  - Posts

---
Today I woke up to another abrupt Google change, the background image. I know some people want so much candy they can&#8217;t see the cane. Some of these changes Google has been making lately makes me wonder if the next time I open up vanilla ice cream I will be looking at a tub of Rocky Road. Yes, the background is only there for a day as publicity for the new feature to make Google more bingesque but I would be pretty upset if my vanilla ice cream turned to Rocky Road as well, even if only for a day.

[<img class="alignleft size-medium wp-image-754" title="google_background" src="http://www.cmdln.org/wp-content/uploads/2010/06/google_background-300x221.png" alt="" width="300" height="221" srcset="http://www.cmdln.org/wp-content/uploads/2010/06/google_background-300x221.png 300w, http://www.cmdln.org/wp-content/uploads/2010/06/google_background-1024x755.png 1024w, http://www.cmdln.org/wp-content/uploads/2010/06/google_background.png 1154w" sizes="(max-width: 300px) 100vw, 300px" />][1]

 [1]: http://www.cmdln.org/wp-content/uploads/2010/06/google_background.png