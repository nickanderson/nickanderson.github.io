---
title: Citrix makes Xen Enterprise Free
author: Nick Anderson
type: post
date: 2009-02-23T20:54:52+00:00
url: /2009/02/23/citrix-makes-xen-enterprise-free/
aktt_notify_twitter:
  - yes
aktt_tweeted:
  - 1
categories:
  - Posts
tags:
  - citrix
  - virtualization
  - xen

---
Today Citrix announced that it will distribute its enterprise packaging of Xen for free. This brings fancy gui management and features available in VMwares ESX server to everyone. (Actually I&#8217;m not clear if just the ability is there or if they actually are letting the gui go as well.)

This is not a scaled down, limited version of the hypervisor. From the end of March on, there will be only one edition of XenServer which and it will be free.

The ability to manage multiple hosts via XenCenter, live migration via XenMotion, and resource sharing pools are all included in this free release.

Read the [press release here][1].

I can&#8217;t wait to see what VMware does in response.

 [1]: http://www.citrix.com/English/NE/news/news.asp?newsID=1687130