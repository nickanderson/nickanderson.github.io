---
title: I am so excited! And I just cant hide it!
author: Nick Anderson
type: post
date: 2013-05-01T17:10:20+00:00
url: /2013/05/01/i-am-so-excited-and-i-just-cant-hide-it/
categories:
  - Posts
tags:
  - CFEngine

---
Today [<img class="alignright  wp-image-1181" alt="NIKON_D5000_20120908T114952_02" src="http://www.cmdln.org/wp-content/uploads/2013/05/NIKON_D5000_20120908T114952_02.jpg" width="294" height="442" srcset="http://www.cmdln.org/wp-content/uploads/2013/05/NIKON_D5000_20120908T114952_02.jpg 1360w, http://www.cmdln.org/wp-content/uploads/2013/05/NIKON_D5000_20120908T114952_02-199x300.jpg 199w, http://www.cmdln.org/wp-content/uploads/2013/05/NIKON_D5000_20120908T114952_02-680x1024.jpg 680w" sizes="(max-width: 294px) 100vw, 294px" />][1]I start a new journey with some of the smartest people on the planet. I have accepted a position with <a href="https://cfengine.com/" target="_blank">CFEngine</a>. Primarily I will be assisting customers with the evaluation, design, implementation and policy writing. If you know me from the CFEngine community, don&#8217;t worry I only plan to increase my activity and continue to help in any way I can. Now one of my favourite hobbies is my job!

I am very excited to be joining such a great team and very honoured to have this opportunity.

 [1]: http://www.cmdln.org/wp-content/uploads/2013/05/NIKON_D5000_20120908T114952_02.jpg