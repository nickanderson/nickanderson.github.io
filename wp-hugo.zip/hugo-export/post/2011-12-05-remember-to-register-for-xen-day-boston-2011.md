---
title: Remember to Register for Xen Day Boston 2011
author: Nick Anderson
type: post
date: 2011-12-05T15:36:02+00:00
url: /2011/12/05/remember-to-register-for-xen-day-boston-2011/
categories:
  - Posts
tags:
  - sysadmin
  - xen

---
Just a reminder that Xen Day Boston 2011 is coming up (December 9th).

There&#8217;s still room to register, but spots are going fast!

For more information see:
  
http://blog.xen.org/index.php/2011/12/02/xen-day-presenters/