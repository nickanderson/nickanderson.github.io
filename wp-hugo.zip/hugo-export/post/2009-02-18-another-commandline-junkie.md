---
title: Another commandline junkie
author: Nick Anderson
type: post
date: 2009-02-18T16:08:58+00:00
url: /2009/02/18/another-commandline-junkie/
aktt_notify_twitter:
  - yes
aktt_tweeted:
  - 1
categories:
  - Posts
tags:
  - one liner

---
Waddya know I&#8217;m not the only geek with an affinity for the console. This could be interesting. [Repository of useful one liners][1].

 [1]: http://www.commandlinefu.com