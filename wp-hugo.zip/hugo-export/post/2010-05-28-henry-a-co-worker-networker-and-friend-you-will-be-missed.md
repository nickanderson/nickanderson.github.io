---
title: 'Henry: a co-worker, networker, and friend. You will be missed'
author: Nick Anderson
type: post
date: 2010-05-28T16:36:23+00:00
url: /2010/05/28/henry-a-co-worker-networker-and-friend-you-will-be-missed/
openid_comments:
  - 'a:1:{i:0;s:4:"1088";}'
categories:
  - Posts

---
[<img class="alignleft size-full wp-image-748" title="Henry Sieff" src="http://www.cmdln.org/wp-content/uploads/2010/05/hsieff.jpeg" alt="" width="104" height="78" />][1] I don&#8217;t have much to say about the loss. Henry Sieff was a brilliant network, security engineer and friend.

 [1]: http://www.cmdln.org/wp-content/uploads/2010/05/hsieff.jpeg