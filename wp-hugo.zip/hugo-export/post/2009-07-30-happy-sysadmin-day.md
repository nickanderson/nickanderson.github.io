---
title: Happy SysAdmin Day!
author: Nick Anderson
type: post
date: 2009-07-31T05:25:49+00:00
url: /2009/07/30/happy-sysadmin-day/
syntaxhighlighter_encoded:
  - 1
categories:
  - Posts

---
Congratulations to everyone in the club. You have successfully navigated another trip around the sun. Today is not the day to worry about your infrastructure falling apart today is a day for celebration. Ok maybe thats not exactly true, celebrate after you get your network and systems in check :).