---
title: 'One liners: a tip'
author: Nick Anderson
type: post
date: 2009-08-22T19:07:46+00:00
url: /2009/08/22/one-liners-a-tip/
syntaxhighlighter_encoded:
  - 1
categories:
  - Posts
tags:
  - command line
  - console
  - tip

---
Have you ever started writing a one-liner and half way in realized it was a bit more complex than you first thought?

If your shell is bash, next time that happens try ctrl-x ctrl-e.

It will take your current line and stuff it into the your default editor (export EDITOR=vim).