---
title: vimpress test
author: Nick Anderson
type: post
date: 2008-10-26T02:49:58+00:00
url: /2008/10/25/vimpress-test/
aktt_tweeted:
  - 1
categories:
  - Posts
tags:
  - test
  - vimpress

---
This is just a test post from vimpress. Vimpress is a vim plugin to post to wordpress. Seems there is an issue with not supporting the more tag, but it is much easier to write a post in vim than it is to use the builtin editor.