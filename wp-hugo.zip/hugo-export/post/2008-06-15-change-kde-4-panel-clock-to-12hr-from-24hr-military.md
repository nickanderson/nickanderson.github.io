---
title: Change KDE 4 panel clock to 12hr from 24hr military
author: Nick Anderson
type: post
date: 2008-06-16T01:43:05+00:00
url: /2008/06/15/change-kde-4-panel-clock-to-12hr-from-24hr-military/
categories:
  - Posts
tags:
  - kde4
  - time format

---
It&#8217;s not that I can not read 24 hour time, it&#8217;s just a pain to deal with on a daily basis. I was raised with 12 hr, and its just quicker for me to read. So if you are running KDE4 and you would prefer 12 hour format in your panel read on.<!--more-->

In KDE4 the panel takes its configuration from the global settings so you need to change the time format under System Settings.

System Settings -> Regional &#038; Language -> Time &#038; Dates -> Time Format