---
title: 'NetApp &#8211; Customer Service WIN!'
author: Nick Anderson
type: post
date: 2011-12-15T17:02:25+00:00
url: /2011/12/15/netapp-customer-service-win/
categories:
  - Posts
tags:
  - customer service
  - sysadmin
  - win

---
[<img class="alignleft size-thumbnail wp-image-925" title="thumbsup_000" src="http://www.cmdln.org/wp-content/uploads/2011/12/thumbsup_000-150x150.jpg" alt="" width="150" height="150" />][1]I just wanted to share my NetApp customer service experience since usually people only share negative experiences. I needed to download a mib for a NetApp today. I really don&#8217;t like that I have to register an account just to download a mib but whatever. I was really upset after registering the account and entering a system-id to find that I didn&#8217;t have access to download any mibs.

I saw that feedback button glaring at me so decided to give it a shot, left a &#8220;very dissatisfied&#8221; about download experience review. Within an hour I had an email that my access had been changed, and I now have access to download the mibs.

Good job NetApp, in my experience those feedback forms usually go unanswered.

 [1]: http://www.cmdln.org/wp-content/uploads/2011/12/thumbsup_000.jpg