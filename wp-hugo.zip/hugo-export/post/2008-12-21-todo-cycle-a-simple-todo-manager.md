---
title: 'todo-cycle a simple todo manager based on &#8220;The Cycle&#8221;'
author: Nick Anderson
type: post
date: 2008-12-22T04:30:09+00:00
url: /2008/12/21/todo-cycle-a-simple-todo-manager/
aktt_notify_twitter:
  - no
aktt_tweeted:
  - 1
categories:
  - Posts

---
I posted about [Tom Limoncelli][1] and his [Time Management for System Administrators][2]. I have written a simple wrapper to do pre and post processing of a todo file as it is opened and closed to somewhat mirror &#8220;the cycle&#8221;. If your interested you can find a bit more information on [todo-cycle here][3].

 [1]: http://www.everythingsysadmin.com
 [2]: http://www.amazon.com/Management-System-Administrators-Thomas-Limoncelli/dp/0596007833
 [3]: http://www.cmdln.org/projects/todo-cycle