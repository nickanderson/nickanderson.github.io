---
title: Slowdown VMware Bios Screen
author: Nick Anderson
type: post
date: 2008-05-03T22:35:04+00:00
url: /2008/05/03/slowdown-vmware-bios-screen/
categories:
  - Posts
tags:
  - bios
  - increse timeout
  - slowdown
  - vmware

---
Working with virtual machines after having worked with physical machines can be a wonderful experience. Wonderful that is until the bios scree blows past you several times.<!--more-->

<!--adsense-->

Changing the boot dealy for vmware is pretty easy. One line needs to be added to the vmx configuration file.
  
`Working with virtual machines after having worked with physical machines can be a wonderful experience. Wonderful that is until the bios scree blows past you several times.<!--more-->

<!--adsense-->

Changing the boot dealy for vmware is pretty easy. One line needs to be added to the vmx configuration file.
  
`