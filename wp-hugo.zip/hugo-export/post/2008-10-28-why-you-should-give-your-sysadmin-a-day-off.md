---
title: Why you should give your sysadmin a day off
author: Nick Anderson
type: post
date: 2008-10-29T03:43:49+00:00
url: /2008/10/28/why-you-should-give-your-sysadmin-a-day-off/
aktt_tweeted:
  - 1
categories:
  - Posts

---
We will eventually go crazy without some rest. Looks like solaris cluster may have saved the day. Us Linux admins unfortunately do not have ZFS.

<div class="sociable">
  <div class="sociable_tagline">
    <strong>Share and Enjoy:</strong>
  </div>
  
  <ul>
    <li>
      <a rel="nofollow" target="_blank" href="http://digg.com/submit?phase=2&url=http%3A%2F%2Fwww.cmdln.org%2F2008%2F10%2F28%2Fwhy-you-should-give-your-sysadmin-a-day-off%2F&title=Why%20you%20should%20give%20your%20sysadmin%20a%20day%20off" title="Digg"><img src="http://www.cmdln.org/wp-content/plugins/sociable/images/digg.png" title="Digg" alt="Digg" class="sociable-hovers" /></a>
    </li>
    <li>
      <a rel="nofollow" target="_blank" href="http://sphinn.com/submit.php?url=http%3A%2F%2Fwww.cmdln.org%2F2008%2F10%2F28%2Fwhy-you-should-give-your-sysadmin-a-day-off%2F&title=Why%20you%20should%20give%20your%20sysadmin%20a%20day%20off" title="Sphinn"><img src="http://www.cmdln.org/wp-content/plugins/sociable/images/sphinn.png" title="Sphinn" alt="Sphinn" class="sociable-hovers" /></a>
    </li>
    <li>
      <a rel="nofollow" target="_blank" href="http://del.icio.us/post?url=http%3A%2F%2Fwww.cmdln.org%2F2008%2F10%2F28%2Fwhy-you-should-give-your-sysadmin-a-day-off%2F&title=Why%20you%20should%20give%20your%20sysadmin%20a%20day%20off" title="del.icio.us"><img src="http://www.cmdln.org/wp-content/plugins/sociable/images/delicious.png" title="del.icio.us" alt="del.icio.us" class="sociable-hovers" /></a>
    </li>
    <li>
      <a rel="nofollow" target="_blank" href="http://www.facebook.com/sharer.php?u=http%3A%2F%2Fwww.cmdln.org%2F2008%2F10%2F28%2Fwhy-you-should-give-your-sysadmin-a-day-off%2F&t=Why%20you%20should%20give%20your%20sysadmin%20a%20day%20off" title="Facebook"><img src="http://www.cmdln.org/wp-content/plugins/sociable/images/facebook.png" title="Facebook" alt="Facebook" class="sociable-hovers" /></a>
    </li>
    <li>
      <a rel="nofollow" target="_blank" href="http://www.google.com/bookmarks/mark?op=edit&bkmk=http%3A%2F%2Fwww.cmdln.org%2F2008%2F10%2F28%2Fwhy-you-should-give-your-sysadmin-a-day-off%2F&title=Why%20you%20should%20give%20your%20sysadmin%20a%20day%20off" title="Google"><img src="http://www.cmdln.org/wp-content/plugins/sociable/images/googlebookmark.png" title="Google" alt="Google" class="sociable-hovers" /></a>
    </li>
    <li>
      <a rel="nofollow" target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&url=http%3A%2F%2Fwww.cmdln.org%2F2008%2F10%2F28%2Fwhy-you-should-give-your-sysadmin-a-day-off%2F&title=Why%20you%20should%20give%20your%20sysadmin%20a%20day%20off&source=cmdln.org+%28a+sysadmin+blog%29+a+system+administrators+mutterings&summary=We%20will%20eventually%20go%20crazy%20without%20some%20rest.%20Looks%20like%20solaris%20cluster%20may%20have%20saved%20the%20day.%20Us%20Linux%20admins%20unfortunately%20do%20not%20have%20ZFS.%0D%0A" title="LinkedIn"><img src="http://www.cmdln.org/wp-content/plugins/sociable/images/linkedin.png" title="LinkedIn" alt="LinkedIn" class="sociable-hovers" /></a>
    </li>
    <li>
      <a rel="nofollow" target="_blank" href="http://reddit.com/submit?url=http%3A%2F%2Fwww.cmdln.org%2F2008%2F10%2F28%2Fwhy-you-should-give-your-sysadmin-a-day-off%2F&title=Why%20you%20should%20give%20your%20sysadmin%20a%20day%20off" title="Reddit"><img src="http://www.cmdln.org/wp-content/plugins/sociable/images/reddit.png" title="Reddit" alt="Reddit" class="sociable-hovers" /></a>
    </li>
    <li>
      <a rel="nofollow" target="_blank" href="http://slashdot.org/bookmark.pl?title=Why%20you%20should%20give%20your%20sysadmin%20a%20day%20off&url=http%3A%2F%2Fwww.cmdln.org%2F2008%2F10%2F28%2Fwhy-you-should-give-your-sysadmin-a-day-off%2F" title="Slashdot"><img src="http://www.cmdln.org/wp-content/plugins/sociable/images/slashdot.png" title="Slashdot" alt="Slashdot" class="sociable-hovers" /></a>
    </li>
    <li>
      <a rel="nofollow" target="_blank" href="http://twitthis.com/twit?url=http%3A%2F%2Fwww.cmdln.org%2F2008%2F10%2F28%2Fwhy-you-should-give-your-sysadmin-a-day-off%2F" title="TwitThis"><img src="http://www.cmdln.org/wp-content/plugins/sociable/images/twitter.png" title="TwitThis" alt="TwitThis" class="sociable-hovers" /></a>
    </li>
  </ul>
</div>