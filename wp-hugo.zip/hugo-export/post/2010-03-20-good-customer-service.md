---
title: Good Customer Service
author: Nick Anderson
type: post
date: 2010-03-20T21:17:10+00:00
url: /2010/03/20/good-customer-service/
syntaxhighlighter_encoded:
  - 1
tweetlyUpdater_bitlyUrl:
  - http://bit.ly/bvC0dA
categories:
  - Posts
tags:
  - bornfree
  - kudos
  - notfail
  - readynas

---
In the last week my wife and I have both experienced excellent customer service. All too often you only hear about a company when they do something bad (see all my fail posts). I just want to be sure to give kudos to both of these companies.

1) BornFree: My wife ordered some [BornFree Spouts][1] as we start transitioning our son to sippy cups. She said about 5 minutes after she hit the order button she realized she should have ordered more. So she called the company to change her order. The person she spoke with said it had already been packaged up (wow that was fast). But instead of her having to place a new order and pay shipping two times they said they would just toss in an extra set of spouts for FREE. How bout that? They certainly didn&#8217;t have to do that we were more than willing to pay for them. But hey thats good customer service and my wife will likely recommend them for a long time.

2) I have an old [ReadyNas][2] with 4 drive bays. Some where along the line I lost the brackets for one of the drives. Its been running for a long time with one loose drive but today I decided to see where I could hunt a set down. Its an old discontinued unit so my hopes were not high. I contacted a guy (chirpa) on their forums asking if he knew where I could purchase a set. He said to just send him some pictures and my address. Its not a part they carry but he said he could find some in the lab and just send them to me for FREE. Thats also great customer service. Even though that unit is no longer in production and employee took the time to respond to my mail on a saturday and will hunt some esoteric rails down for me on monday and ship them out.

So don&#8217;t forget to point out good customer experiences you have. Its easy to rant about a bad experience, but take that same extra time to shine a light and give credit when its deserved.

 [1]: http://www.newbornfree.com/Spouts/109535/info.aspx
 [2]: http://www.readynas.com/