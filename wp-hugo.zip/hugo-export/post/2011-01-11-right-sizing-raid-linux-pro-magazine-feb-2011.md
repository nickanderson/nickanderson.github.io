---
title: 'Right Sizing RAID &#8211; Linux Pro Magazine Feb 2011'
author: Nick Anderson
type: post
date: 2011-01-11T21:50:39+00:00
url: /2011/01/11/right-sizing-raid-linux-pro-magazine-feb-2011/
categories:
  - Posts

---
Looks like my article on right sizing RAID subsystems made it into the Feb 2011 Sys Admin issue of Linux Pro Magazine. Go grab a copy and flame me ;).