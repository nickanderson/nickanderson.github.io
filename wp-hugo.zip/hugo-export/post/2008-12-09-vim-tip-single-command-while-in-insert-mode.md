---
title: Vim Tip single command while in insert mode
author: Nick Anderson
type: post
date: 2008-12-09T21:37:55+00:00
url: /2008/12/09/vim-tip-single-command-while-in-insert-mode/
aktt_notify_twitter:
  - no
categories:
  - Posts
tags:
  - vim

---
I use vim for the vast majority of my editing. It can be a bit cumbersom to hit esc each time you want to perform a command while in insert mode. Using ctrl o will put you in command mode for the next command. Give it a try sometime it may or may not make you more effective with vim.