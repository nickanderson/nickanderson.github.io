---
title: Old new SA Pro podcast
author: Nick Anderson
type: post
date: 2008-12-20T17:01:22+00:00
url: /2008/12/20/old-new-sa-pro-podcast/
aktt_notify_twitter:
  - no
categories:
  - Posts
tags:
  - podcast

---
It&#8217;s not new news but I havent seen anyone else mention it. Ben Rockwood over at cuddletech had his second SA Pro podcast with Tom Limoncelli, it covers time management. It&#8217;s a good listen, I&#8217;m still waiting for him to setup a feed for the podcasts. Tom has some good advice, I have picked up a few things and read his Time Management for System Administrators since listening to the podcast. At any rate check out the podcast http://cuddletech.com/sapro/.