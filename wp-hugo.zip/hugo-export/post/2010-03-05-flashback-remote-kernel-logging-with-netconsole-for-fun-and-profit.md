---
title: 'Flashback: Remote kernel logging with netconsole for fun and profit'
author: Nick Anderson
type: post
date: 2010-03-05T15:17:23+00:00
url: /2010/03/05/flashback-remote-kernel-logging-with-netconsole-for-fun-and-profit/
syntaxhighlighter_encoded:
  - 1
tweetlyUpdater_bitlyUrl:
  - http://bit.ly/cGas97
categories:
  - Posts
tags:
  - flashback
  - logging
  - netconsole
  - sysadmin

---
Have you ever had a machine that was a bit flaky? You know those ones that occasionally crash and don&#8217;t write anything useful into the log file. Sometimes you can capture those messages with netconsole. Just revisiting a small walk-through I wrote a while back.

<a title="Permanent Link to Remote kernel logging with  netconsole for fun and profit" rel="bookmark" href="../2009/01/21/remote-kernel-logging-with-netconsole-for-fun-and-profit/">Remote kernel logging with netconsole for fun and profit</a>