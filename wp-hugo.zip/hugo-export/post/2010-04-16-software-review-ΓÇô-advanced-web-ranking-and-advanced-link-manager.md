---
title: Software Review – Advanced Web Ranking and Advanced Link Manager
author: Mark Bosma
type: post
date: 2010-04-16T19:13:35+00:00
url: /2010/04/16/software-review-–-advanced-web-ranking-and-advanced-link-manager/
syntaxhighlighter_encoded:
  - 1
aktt_tweeted:
  - 1
categories:
  - Posts
tags:
  - alm
  - awr
  - seo

---
As anyone in the search industry can tell you, getting website traffic for your primary keywords and phrases in organic search can mean the difference between the success or failure of your website.  If you are a site owner, website failure can have a detrimental impact on the profitability of your company.  If instead you are an SEO or web consultant, this can make or break your reputation in the industry.

There are numerous steps that can be employed to steer us toward success in search, with a few listed here.  Start by selecting the keywords that your customers likely search for.  Target those keywords in the content of your website.  Build links to your website, using keyword anchor text where possible.  Monitor your search results to see where you are gaining position on the results page, where you are losing position, and use these insights to hone your processes and allocate resources.  In other words, it can take a lot of work!

For this reason, automation tools can be invaluable for these tasks.  Caphyon ([http://www.caphyon.com][1]) has just released version 7.2 of their Advanced Web Ranking (AWR) and Advanced Link Manager (ALM) suite, intended for this very purpose. 



### Starting Out – Advanced Web Ranking

[<img class="size-full wp-image-633 alignleft" src="http://www.cmdln.org/wp-content/uploads/2010/04/ai-128x128.png" alt="Advanced Web Ranking Logo" width="128" height="128" srcset="http://www.cmdln.org/wp-content/uploads/2010/04/ai-128x128.png 128w, http://www.cmdln.org/wp-content/uploads/2010/04/ai-128x128-50x50.png 50w" sizes="(max-width: 128px) 100vw, 128px" />][2]Let&#8217;s pretend we are a small sysadmin consulting firm – we have started an initiative to improve our [website ranking][3] (and hopefully traffic!), but we face stiff website competition from larger, established sites, both locally and nationwide.  Where do we stand?  Do we currently rank for any of the keywords relating to our core products or services?  Are there other keywords that we should be watching?  What about our competition?

We can work out all of these answers by hand, or we can setup <a href="http://www.advancedwebranking.com/" target="_blank">Advanced Web Ranking</a> and have it do much of the work for us &#8211; saving a lot of time and resources.  To get started we just need to step through a quick Project Wizard.  Select which search engines you want, which keywords you want to keep an eye on, which websites you want to track, and your communication settings.  AWR will then take off and start collecting stats!

The result is a collection of data which shows us how we rank for each of our keywords (per search engine), the top sites for a given keyword, and whether we moved up or down since our last check.  These results can be viewed in various charts, graphs, and reports – all complete with filtering and sorting options that make it easy to parse out the information that is most useful to us.  These results are stored on your computer for comparison with future data.

<p style="text-align: center">
  <p>
    <a href="http://www.cmdln.org/wp-content/uploads/2010/04/awr-keyword-suggestion-cropped2.png"><img class="aligncenter size-full wp-image-631" src="http://www.cmdln.org/wp-content/uploads/2010/04/awr-keyword-suggestion-cropped2.png" alt="AWR Keyword Suggestion Tool" width="500" height="157" srcset="http://www.cmdln.org/wp-content/uploads/2010/04/awr-keyword-suggestion-cropped2.png 500w, http://www.cmdln.org/wp-content/uploads/2010/04/awr-keyword-suggestion-cropped2-300x94.png 300w" sizes="(max-width: 500px) 100vw, 500px" /></a>
  </p>
  
  <p>
    <em>One feature I like is that as you type your keywords into the project wizard, a dropdown box populates with possible completions of your word or phrase, as well as the number of google results for each. This <a href="http://www.advancedwebranking.com/feats-keyword-research-tool.html">keyword research tool</a> alone can give you valuable keyword ideas on-the-fly without any switching between apps.</em>
  </p>
  
  <p>
  </p>
  
  <h3>
    Automation?
  </h3>
  
  <p>
    “Spectacular,” you may be saying, “but remembering to open Advanced Web Ranking and click &#8216;Start Update&#8217; once a week or twice a month really sounds like a lot of work!”  Fortunately, Advanced Web Ranking has features that can handle this as well.  I can schedule this update to run once a week at a given time, e-mail selected reports to myself (custom reports, if I so desire), and trigger special notifications if certain incidents occur (for example, a ranking drop of 5 or more since last time).
  </p>
  
  <p>
  </p>
  
  <h3>
    Now What?
  </h3>
  
  <p>
    Now that we have some baseline for how our site is performing against our competition, what can we do to leverage this information and improve our site&#8217;s <a href="http://www.advancedwebranking.com/">search engine ranking</a>?  If we are not ranking as well as we hoped, our first reaction should be to check the content of our pages to see how they perform.  Once again, Advanced Web Ranking has a tool that can help.  The Keyword Analysis tool looks at basic page metrics (title, links, image ALTs, headings, etc) and shows us how well they perform for a number of keywords.  This is excellent groundwork for starting a more in-depth manual review later.
  </p>
  
  <p>
    Maybe we rank fine for our initial set of keywords, but wonder what else we might be missing.  Are there other, related keywords that we should be targeting?  The built-in Keywords Research Tool allows us to select from a number of suggestion sources including Google Suggest, WordTracker, Yahoo Related Keywords Search, and more.  From the full list of suggestions, we can select the ones we desire and add them directly to our project – quick and easy.
  </p>
  
  <p>
    So far, Advanced Web Ranking has shown us how well we are doing, and has given us tools to help target the on-site factors of our website that need work (or need to be created altogether!).  But what about our off-site factors?  What about links?  On-site content is only one piece of the puzzle, so Caphyon steps in yet again with today&#8217;s second application – Advanced Link Manager.
  </p>
  
  <p>
  </p>
  
  <h3>
    Starting Out – Advanced Link Manager
  </h3>
  
  <p>
    <a href="http://www.cmdln.org/wp-content/uploads/2010/04/alm-128x128.png"><img class="alignleft size-full wp-image-636" src="http://www.cmdln.org/wp-content/uploads/2010/04/alm-128x128.png" alt="Advanced Link Manager Logo" width="128" height="128" srcset="http://www.cmdln.org/wp-content/uploads/2010/04/alm-128x128.png 128w, http://www.cmdln.org/wp-content/uploads/2010/04/alm-128x128-50x50.png 50w" sizes="(max-width: 128px) 100vw, 128px" /></a>For years, the major search engines have used links as a primary ranking factor for website search results.  Ignoring web spam and other complexities for the moment, we can consider the quantity of links as indicative of popularity our site, the authority of the linking domains as indicative of the importance of our site, and the text of the links as indicative of what our site is about.  This leads to new questions – How many links does our website have?  Who links to us?  What link text do other sites use for us?  And again&#8230; What about our competition?
  </p>
  
  <p>
    <a href="http://www.advancedlinkmanager.com/" target="_blank">Advanced Link Manager</a> is meant to help answer those questions and give us the information that we need to beat the competition and stay competitive on the web.  Starting a new project in ALM is a simple process – we first enter the domain of the site we want to monitor, then select the search engines that we want to use for results – that&#8217;s it..  ALM generates results using a multi-step process which begins by using search results to find linking pages.  Each linking page is then verified (does it still exist?) and classified (text of the link? authority of the page? etc).
  </p>
  
  <p>
  </p>
  
  <h3>
    Automation and Other Features
  </h3>
  
  <p>
    Much like Advanced Web Ranking discussed above, ALM allows you to gather, parse, and view your data all in one place.  You can create custom reports, schedule tasks, and e-mail reports for yourself.  The information gathered from each linking page (referrer) includes alexa rank, outbound links and backlinks as well as link text, URL title, and whether the links are no-followed. Serving as an excellent <a href="http://www.advancedlinkmanager.com/">link popularity</a> tool, ALM gathers many aspects of link data, not just one or two.
  </p>
  
  <p>
    <a href="http://www.cmdln.org/wp-content/uploads/2010/04/ALM-domains-cropped.png"><img class="aligncenter size-full wp-image-639" src="http://www.cmdln.org/wp-content/uploads/2010/04/ALM-domains-cropped.png" alt="Advanced Link Manager Unverified Domains" width="500" height="201" srcset="http://www.cmdln.org/wp-content/uploads/2010/04/ALM-domains-cropped.png 500w, http://www.cmdln.org/wp-content/uploads/2010/04/ALM-domains-cropped-300x120.png 300w" sizes="(max-width: 500px) 100vw, 500px" /></a>
  </p>
  
  <p>
    <em>Advanced Link Manager&#8217;s link results are initially gathered as &#8220;Unverified Referrers&#8221; until each domain (along with specs and details) is checked and verified &#8211; only then are they moved to the final &#8220;Referrers&#8221; list.</em>
  </p>
  
  <p>
  </p>
  
  <h3>
    Now What?
  </h3>
  
  <p>
    With this newfound knowledge of our inbound link status, as well as the link status of our competitors, we find a place to start with our link building.  We can look at our competitors links and start trying to duplicate them, starting with the highest quality links first.  Maybe there is an article site where they have been making posts.  Maybe they have been participating in several forums.  Advanced Link Manager makes it easy to discover these trends and use them to your own benefit.
  </p>
  
  <p>
    Another aspect of backlink profiling is using it to discover what the public thinks your site is about.  Perhaps we use Advanced Link Manager&#8217;s Referrer report to go through the backlinks of our command-line sysadmin blog, only to discover a surprisingly large amount of link text referring to “virtualization” or “virtualization blog”.  This could indicate that a previously unknown portion of our visitor base sees us primarily as an expert on virtualization.  This information could prompt new types of posts, or even new types of advertising, targeting this visitor segment.
  </p>
  
  <p>
  </p>
  
  <h3>
    Conclusion
  </h3>
  
  <p>
    This combination of software by Caphyon (web ranking and <a href="http://www.advancedlinkmanager.com/download.html">link manager</a>) can lend powerful capabilities to your internet marketing arsenal.  The ability to monitor the ranks and backlinks of our websites (as well as those of our competitors) can save a massive amount of time versus the old alternative of parsing such information by hand.
  </p>
  
  <p>
    Advanced Web Ranking and Advanced Link Manager are both easy to use, with help files and tutorials that walk you through the basics of starting a project and making use of the data.  The look and feel of each is very similar, so becoming acquainted with one makes learning the other even easier.  You can expect to have your first project  ready within minutes of starting the program.
  </p>
  
  <p>
    A 30-day trial of each is available, giving ample time to start a few projects and familiarize yourself with the feature-set.  Purchase options are broken down into 4 tiers, from Standard to Server.  This makes the software equally viable for small businesses or professional search marketing firms.
  </p>
  
  <p>
    And finally, one last feature that is big for myself (and likely most of the readers here) is that this software is all cross-platform (Win/Mac/Linux). So in other words &#8211; you can have it while still avoiding Windows. Always a good thing.
  </p>
  
  <p>
  </p>
  
  <h3>
    Caveats
  </h3>
  
  <p>
    As always, any discussion of rank checking software and backlink profile tools comes with a caveat – Google officially frowns on such software, so exercise a bit of caution when performing your updates.  For example, set your delay times to “human” values and schedule automatic updates (to help avoid that pesky urge to check your rankings obsessively).
  </p>
  
  <p>
  </p>
  
  <h3>
    Credits
  </h3>
  
  <p>
    This post was written by Mark Bosma of <a href="http://www.leapfrogseo.com">LeapfrogSEO.com &#8211; small business seo and web consulting</a>. Feel free to drop a comment here with any additional feedback or questions you have on my experience with AWR and ALM. Thanks!
  </p>
  
  <div>
    <span style="font-family: 'Times New Roman', 'Times New Roman', 'Bitstream Charter', Times, serif;font-size: small"><br /> </span>
  </div>

 [1]: http://www.caphyon.com/
 [2]: http://www.cmdln.org/wp-content/uploads/2010/04/ai-128x128.png
 [3]: http://www.advancedwebranking.com/features.html