---
title: Welcome back traffic
author: Nick Anderson
type: post
date: 2009-07-03T23:49:51+00:00
url: /2009/07/03/welcome-back-traffic/
aktt_notify_twitter:
  - no
categories:
  - Posts

---
I know I&#8217;ve been absent. I am not appologising I&#8217;ve been adjusting to the new job and its been keeping me busy.  I did notice that my traffic tanked around the 20th of May and pretty much stayed that way until June 9th. I don&#8217;t know where everyone went but I&#8217;m glad to have you back.

I don&#8217;t really have any ideas for articles at the moment  but I am working on some virtualization at work. I&#8217;ve installed both ESXi and Xenserver. Personally I prefer Xenserver but that probably comes from my history with using the opensource Xen. It just seems that ESXi is more of a &#8220;demo&#8221; than anything else. Once you want to do just about anything your going to be paying for an ESX license. Xenserver seems to fulfill all of my current requirements without additional licensing. To be clear I don&#8217;t mind paying for advanced features when I can afford to but I do not like feeling trapped into buying things. Thats probably why I stuck with the opensource Xen stuff in debian until now. I also have some snmp monitoring and possibly some reverse proxy stuff in my future. So depending on what things might be blog worthy those are some things I might be blogging about in the nearish future.

Just another accolade for Xenserver &#8230;. I love provisioning a new vm in about 8 seconds, setting up the hostname in another 30 seconds, and having a functioning nginx reverse proxy within a half hour (that included reading the doc on nginx).