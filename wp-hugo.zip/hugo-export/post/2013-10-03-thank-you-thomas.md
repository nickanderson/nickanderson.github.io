---
title: Thank you Thomas
author: Nick Anderson
type: post
date: 2013-10-03T14:12:32+00:00
url: /2013/10/03/thank-you-thomas/
categories:
  - Posts
tags:
  - lopsa

---
I want to take a minute to thank Thomas Leyer for all of his hard work and dedicated service to the LOPSA Mentorship Program Team. Thomas has been a volunteer since the programs inception, and has chaired the program for the past three years! Thanks Thomas!

[<img class="alignright size-full wp-image-1194" alt="applause_sign" src="http://www.cmdln.org/wp-content/uploads/2013/10/applause_sign.jpg" width="254" height="255" srcset="http://www.cmdln.org/wp-content/uploads/2013/10/applause_sign.jpg 254w, http://www.cmdln.org/wp-content/uploads/2013/10/applause_sign-150x150.jpg 150w" sizes="(max-width: 254px) 100vw, 254px" />][1]I think the mentorship program is one of the best things that LOPSA offers. You should consider participating. It&#8217;s a great experience whether you choose to participate in the core team, as a mentor or as a <span>protégé, I guarantee you will learn something, and you will be affecting the future of the profession. A round of applause for Thomas and his years of service, and to the current LOPSA Mentorship Program Team. Keep up the good work!<br /> </span>

 [1]: http://www.cmdln.org/wp-content/uploads/2013/10/applause_sign.jpg