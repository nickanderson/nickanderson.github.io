---
title: Microsoft Mediaroom Personal Server Odyssey
author: Nick Anderson
type: post
date: 2010-01-27T15:09:15+00:00
url: /2010/01/27/microsoft-mediaroom-personal-server-odyssey/
syntaxhighlighter_encoded:
  - 1
categories:
  - Posts
tags:
  - fail
  - Mediaroom
  - Microsoft
  - Personal Server

---
Ewwww, scary isn&#8217;t it. No Its not Halloween, but you may have entered the twilight zone. Right, I never touch Microsoft products. Well in actuality sometimes I do (I just don&#8217;t brag about it). Some of the development at $work uses Microsofts Mediaroom, and I have a &#8220;Personal Server&#8221; (great name right?) that the developers use. I was trying to install the Mediaroom service pack yesterday and took some notes on the process. Some of my friends found it quite entertaining. I found it quite aggravating﻿ as you might imagine.<!--more-->

  1. Attempt to download update
  2. Fail
  3. You need to use IE to do that
  4. Download update with IE
  5. Unzip to desktop
  6. Attempt to apply update
  7. Failed invalid number of parameters runnix command xcopy
  8. try command manually, fail
  9. move extracted folder to C:
 10. Attempt to apply update, pass first task, fail on second
 11. stop personal server
 12. attempt to apply update, fail
 13. start personal server
 14. attempt to apply update, fail
 15. reboot server
 16. attempt update
 17. tie noose
 18. wait for gui
 19. throw rope over rafter
 20. wait for gui
 21. place noose around neck
 22. wait for gui
 23. stand on railing
 24. wait for gui
 25. attempt update
 26. fail
 27. jump from railing
 28. break leg
 29. look at rope
 30. &#8220;Made by Microsoft&#8221;
 31. FUCK
 32. reload OS
 33. reload personal server
 34. attempt update
 35. fail on run CP3 DB Tool
 36. attempt upgrade
 37. pass run CP3 DB Tool
 38. and finally
 39. success!