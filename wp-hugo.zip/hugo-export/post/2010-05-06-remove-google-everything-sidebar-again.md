---
title: 'Remove Google Everything Sidebar &#8212; Again'
author: Nick Anderson
type: post
date: 2010-05-06T13:41:36+00:00
url: /2010/05/06/remove-google-everything-sidebar-again/
aktt_tweeted:
  - 1
categories:
  - Posts
tags:
  - google
  - hack
  - tip

---
Yesterday I had a tip on [removing yourself from any testing for that google sidebar][1] that your likely seeing in your search results now. I woke up to a nasty surprise. After removing the cookie yesterday, today I had the bar again. So I removed the cookie again, and it came right back. Thats when a friend pointed out that google was rolling it out to everyone. OH NO!

Well, luckily you can get a browser extension for [Firefox or Chrome that makes it disappear][2] from the guys over at seotools.com Thanks!

 [1]: http://www.cmdln.org/2010/05/05/remove-google-everything-sidebar/
 [2]: http://www.seotools.com/hide-google-options/