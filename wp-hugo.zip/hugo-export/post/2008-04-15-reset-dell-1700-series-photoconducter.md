---
title: Reset dell 1700 series photoconducter
author: Nick Anderson
type: post
date: 2008-04-16T03:50:16+00:00
url: /2008/04/15/reset-dell-1700-series-photoconducter/
categories:
  - Posts
tags:
  - 1700
  - dell
  - fix
  - imaging drum
  - photo conductor
  - printer
  - reset

---
Ok I hate printers. If anyone has an aged dell 1700 series printer that prints out pages that say to replace the imaging drum over and over (even after replacing it) then you will like this tip.<!--more-->

<!--adsense-->


  
Leave the printer powered on, insert toner cart and leave the door open. Press the cancel button and hold till the leds flash. Now release cancel and close toner cart door. That should reset the photo conductor counter.