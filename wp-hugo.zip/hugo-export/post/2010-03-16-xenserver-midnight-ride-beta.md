---
title: XenServer Midnight Ride Beta
author: Nick Anderson
type: post
date: 2010-03-16T15:55:53+00:00
url: /2010/03/16/xenserver-midnight-ride-beta/
syntaxhighlighter_encoded:
  - 1
tweetlyUpdater_bitlyUrl:
  - http://bit.ly/bRv4FD
categories:
  - Posts
tags:
  - XenServer

---
Citrix has released the beta for the next version of XenServer code named &#8220;Midnight Ride&#8221;.

I&#8217;m looking forward to the enhanced snapshots (memory+disk), and memory over commit for lab environments.

[Get access to the beta program here][1]

 [1]: http://www.citrix.com/lang/English/lp/lp_1340047.asp