---
title: 'Tip: Vim point in time recovery'
author: Nick Anderson
type: post
date: 2008-10-20T19:19:07+00:00
url: /2008/10/20/tip-vim-point-in-time-recovery/
aktt_tweeted:
  - 1
categories:
  - Posts
tags:
  - point in time recovery
  - vim
  - vim undo

---
Hopefully you know how to undo and redo in vim using u and Ctrl-R. But with newer versions of vim you get point in time recovery. with :earlier. Give it a shot, make some changes to a script and then try :earlier 1m. Very cool and an easy way to undo a bunch of changes.