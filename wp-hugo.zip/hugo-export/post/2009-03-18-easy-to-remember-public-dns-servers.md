---
title: Easy to remember public DNS servers
author: Nick Anderson
type: post
date: 2009-03-18T18:22:38+00:00
url: /2009/03/18/easy-to-remember-public-dns-servers/
aktt_notify_twitter:
  - no
categories:
  - Posts
tags:
  - dns

---
Its handy to keep some remote dns servers in your head for troubleshooting. Here are some pretty fast and easy to remember NS ips for you (they are on level3 network).

4.2.2.1
  
4.2.2.2
  
4.2.2.3
  
4.2.2.4
  
4.2.2.5
  
4.2.2.6