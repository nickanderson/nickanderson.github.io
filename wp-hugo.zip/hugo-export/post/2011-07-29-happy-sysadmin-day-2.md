---
title: Happy SysAdmin Day
author: Nick Anderson
type: post
date: 2011-07-29T13:10:57+00:00
url: /2011/07/29/happy-sysadmin-day-2/
categories:
  - Posts

---
In case you weren&#8217;t paying attention in the last few weeks, today is the [12th annual System Administrator Appreciation Day][1]. It&#8217;s always the last Friday in July. A good reminder to not make changes on Fridays so you can stay out drinking with your colleagues.

There are several places having meet-ups, if your near one or are in a position to make a day trip to one I am sure any of them would love to have you.

  *  [Los Angeles, CA][2]
  * [NYC, NY][3]
  * [Columbus, OH][4]
  * [San Francisco, CA][5]
  * [Chicago, IL][6]
  * [Buenos Aires, Argentina][7]

 [1]: http://www.sysadminday.com/
 [2]: http://sysadminday.eventbrite.com
 [3]: http://nycsysadminday.eventbrite.com
 [4]: http://614-sysadmin-day.eventbrite.com
 [5]: http://opendns-sysadminappreciation2011.eventbrite.com
 [6]: https://www.facebook.com/event.php?eid=100672293360534
 [7]: http://eleccionroot.com/index.php