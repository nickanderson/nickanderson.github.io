---
title: Linux Commercials
author: Nick Anderson
type: post
date: 2009-03-19T04:22:36+00:00
url: /2009/03/18/linux-commercials/
aktt_notify_twitter:
  - no
categories:
  - Posts
tags:
  - video

---
The linux foundation has begun the judging period of the &#8220;We&#8217;re Linux&#8221; commercial (answers the I&#8217;m a PC commercials).

Some of my favorites &#8230;
  
<!--more-->

Artistic
  


Could make a good commercials