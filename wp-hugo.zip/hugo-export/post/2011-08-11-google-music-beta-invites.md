---
title: Google Music Beta Invites
author: Nick Anderson
type: post
date: 2011-08-11T15:06:06+00:00
url: /2011/08/11/google-music-beta-invites/
openid_comments:
  - 'a:1:{i:0;s:4:"1172";}'
categories:
  - Posts

---
<del><img class="alignleft" title="Google Music" src="http://www.infogadgetonline.com/wp-content/uploads/2011/05/Google_Music_Beta_Android.jpg" alt="" width="402" height="268" />I have a few invitations, if you want one drop me a line.</del>

For those of you that don&#8217;t know what google music beta is <http://music.google.com>