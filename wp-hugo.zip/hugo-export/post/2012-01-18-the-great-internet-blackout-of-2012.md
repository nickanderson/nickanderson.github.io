---
title: The Great Internet Blackout of 2012
author: Nick Anderson
type: post
date: 2012-01-18T15:11:24+00:00
url: /2012/01/18/the-great-internet-blackout-of-2012/
categories:
  - Posts
tags:
  - blackout
  - freedom
  - PIPA
  - SOPA
  - sysadmin

---
I am happy to see how many sites are participating in the SOPA/PIPA protest today. I am a bit disapointed that facebook did not join (at least yet), and google only doing a doodle seems a little bit on the weak side. Still its nice when  so many people can show support for something so threatening. There is quite a list of sites that are blacked out in one way or another today.

<http://sopastrike.com/>

I encourage you to voice your opposition to SOPA and PIPA as well.  Follow the link below for an easy way to get your representatives contact information, and send them an email.

<https://wfc2.wiredforchange.com/o/9042/p/dia/action/public/>

&nbsp;

&nbsp;