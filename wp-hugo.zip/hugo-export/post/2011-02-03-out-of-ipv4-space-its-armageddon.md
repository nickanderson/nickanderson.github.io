---
title: Out of IPv4 space its armageddon
author: Nick Anderson
type: post
date: 2011-02-03T16:09:57+00:00
url: /2011/02/03/out-of-ipv4-space-its-armageddon/
categories:
  - Posts

---
http://news.morningstar.com/all/market-wire/11710743/free-pool-of-ipv4-address-space-depleted.aspx

Mostly I am looking forward to the sensational stories. A week or so ago I heard a guy on NPR claim that ISPs might try to make people &#8220;share&#8221; Ips and you might end up with a &#8220;party line&#8221; situation.