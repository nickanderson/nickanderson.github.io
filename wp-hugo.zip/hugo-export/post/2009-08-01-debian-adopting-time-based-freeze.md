---
title: Debian adopting time based freeze
author: Nick Anderson
type: post
date: 2009-08-01T18:50:59+00:00
url: /2009/08/01/debian-adopting-time-based-freeze/
syntaxhighlighter_encoded:
  - 1
categories:
  - Posts
tags:
  - debian

---
Debian is departing (if ever so slightly) from the historical mantra &#8220;It ships when its ready&#8221;.

Looks as if Debian has decided time based freeze schedules will help them better manage time. Note they are not adopting time based releases, only the freeze is time based. I personally think this is a good thing. It will still ship when its ready but at least there will be some semblance of a time line for new releases. Thoughts?

Read the announcement [here][1].

 [1]: http://www.debian.org/News/2009/20090729