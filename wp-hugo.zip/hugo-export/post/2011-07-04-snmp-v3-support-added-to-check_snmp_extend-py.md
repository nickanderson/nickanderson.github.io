---
title: SNMP v3 support added to check_snmp_extend.py
author: Nick Anderson
type: post
date: 2011-07-05T03:39:54+00:00
url: /2011/07/04/snmp-v3-support-added-to-check_snmp_extend-py/
categories:
  - Posts
tags:
  - check_snmp_extend
  - github
  - nagios
  - sysadmin

---
[check\_snmp\_extend][1] is a python script that I found orphaned on some Nagios forum. It facilitates using snmpd as an agent for executing Nagios plugin scripts. I adopted it made a few changes and tossed it on github a while back. I&#8217;m happy to merge initial snmp v3 support from [Lee Whalen][2]

 [1]: https://github.com/nickanderson/check_snmp_extend
 [2]: http://blog.fuzzy-logic.org/