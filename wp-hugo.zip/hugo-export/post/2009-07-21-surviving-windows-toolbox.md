---
title: Surviving Windows Toolbox
author: Nick Anderson
type: post
date: 2009-07-21T15:07:28+00:00
url: /2009/07/21/surviving-windows-toolbox/
syntaxhighlighter_encoded:
  - 1
openid_comments:
  - 'a:1:{i:0;s:3:"935";}'
categories:
  - Posts

---
I have to use windows for a few things at my new employeer. I&#8217;ve found a few programs that I just cant survive using windows without.

  * [Launchy][1] &#8211; Gnome-do like launcher
  * [Quotefix][2] &#8211; Properly bottom post when replying to emails
  * [IsoRecorder][3] &#8211; Right click iso and burn
  * [Cygwin][4] &#8211; Linux-like environment for Windows

I still spend very little time in windows so its not too bad but when I am there not having access to those tools drives me batty. What tools do you use to make windows bearable when you are being abused?

 [1]: http://www.launchy.net/
 [2]: http://home.in.tum.de/~jain/software/outlook-quotefix/
 [3]: http://isorecorder.alexfeinman.com/isorecorder.htm
 [4]: http://www.cygwin.com/