---
title: twitter test
author: Nick Anderson
type: post
date: 2009-07-13T05:13:07+00:00
url: /2009/07/12/twitter-test/
syntaxhighlighter_encoded:
  - 1
categories:
  - Posts

---
Sorry for the spam just testing modifications to a plugin