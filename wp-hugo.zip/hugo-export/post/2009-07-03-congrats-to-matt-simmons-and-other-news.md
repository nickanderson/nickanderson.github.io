---
title: Congrats to Matt Simmons and other news
author: Nick Anderson
type: post
date: 2009-07-03T23:28:30+00:00
url: /2009/07/03/congrats-to-matt-simmons-and-other-news/
aktt_notify_twitter:
  - no
categories:
  - Posts

---
If you haven&#8217;t noticed [Matt Simmons][1] moved off of blogspot today. If you have not yet go and check out his new home <http://www.standalone-sysadmin.com>.

In other news I&#8217;ve been slammed. Nothing exceptional to report really I&#8217;ve been spending most of my time doing machine inventory and weeding out unused servers. Yeah not glamorus but its fun in its own way. Ive pulled almost 30 machines from the server room that were unused. Not all of them were on but just getting things cleaned out is a great feeling. Cable management is comming along slowly. I was able to replace our rats nest of cables for one of the DSLAMs with a new patch pannel so that will go a long way to helping me get things cleaned up.

 [1]: http://www.standalone-sysadmin.com