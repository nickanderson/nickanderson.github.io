---
title: Google sends sniper after Linus Torvalds, Linux Doomed due to Chrome OS announcement
author: Nick Anderson
type: post
date: 2009-07-11T00:35:38+00:00
url: /2009/07/10/google-sends-sniper-after-linus-torvalds-linux-doomed-due-to-chrome-os-announcement/
categories:
  - Posts

---
Ha! I have trapped you with my sensationalized headline. Or you didn&#8217;t read this just like I wouldn&#8217;t have :P.

I don&#8217;t know about anyone else but I had to turn off some of my feeds over the past several days. I was sick and tired of all the Chrome OS posts filtering about the net. It&#8217;s not that I don&#8217;t think having google behind another linux platform is a bad idea. Really I think that will be great for Linux in general. The more average people who are exposed to well packaged Linux distributions the better. What I was tired of was all of the sensationalism surrounding it. Here are some of my favorite titles.

  * **Chrome OS: But Will it Run Photoshop?**
  * **Google Drops A Nuclear Bomb On Microsoft. And It&#8217;s Made of _Chrome_.**
  * ****Google could kneecap Microsoft with Chrome OS****
  * ****So, Google announced a new OS using the Linux Kernel. Opinions?****
  * ****Is Google Stealing Ubuntu&#8217;s Thunder?****
  * ****Google Chrome OS: A Free Alternative To Windows 7****
  * ** **Instant-on Linux vendors put on a brave face against Google Chrome OS****
  * ****Microsoft Worldwide Partner Conference: Will Google Chrome OS Steal the Show?****
  * ****Are Google and Microsoft Switching Roles?****
  * ****What does Red Hat, Ubuntu and openSUSE think about Google Chrome OS?****

Actually I didn&#8217;t read all of these because I couldn&#8217;t get past the headlines. For example &#8220;Chrome OS: But Will it Run Photoshop?&#8221;. Seriously is there an actual readership for these stories? Were they written to incite flame-wars? Riddled with in-accuracies and presumptions. I don&#8217;t know I&#8217;ve just had it up to my ears with with these stories. At any rate just reading the headlines is worth a chuckle. 

<div align="left">
  <font size="2">Twitter Poster sponsor : <a href="http://www.lynxtrack.com/afclick.php?o=9214&#038;b=xrf0x7d8&#038;p=39998&#038;l=1&#038;s=Twit1">The Fast Track to Great Abs. 30 Day Trial Offer!</a></font>
</div>