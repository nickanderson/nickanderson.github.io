---
title: Service Providors and Big Brother Wag Each Others Tails Again
author: Nick Anderson
type: post
date: 2009-09-08T04:47:45+00:00
url: /2009/09/07/service-providors-and-big-brother-wag-each-others-tails-again/
syntaxhighlighter_encoded:
  - 1
categories:
  - Posts
tags:
  - cable

---
I love how there is all of this squabbling about what the definition of broadband is.

&#8220;The Commission should continue to look at maximum advertised speed rather than some measure of &#8216;actual&#8217; speed,&#8221;

and

consumers have “access to broadband capability” whenever they have the opportunity to
  
purchase services and equipment that enable them to access the Internet at any time and use the
  
types of applications that are most commonly used today, such as e-mail and web browsing.11 It
  
is this basic “always on” functionality that is most relevant for definitional purposes, more so
  
than the presence or absence of the various detailed characteristics (e.g., latency, jitter,
  
symmetry, mobility) mentioned in the Commission in the Notice.12

[Full Response][1]

I find both quotes pretty interesting. On one hand the Cable commission sounds like they are trying to hide something from the consumer by not wanting to be measured. On the other hand consumers (in my experience) have little knowledge of how the tubes work and I could see litigation being brought about because someone saturated his uplink and was then repeated fragged losing his perfect score.

I also think its funny that most commonly used conveniently leaves out &#8220;rich&#8221; media like streaming audio and video but these are daily parts of life any more. Personally I would lump it in with web browsing but try telling that to your cable provider and walking away with your bits still attached. (think bandwidth based billing)

 [1]: http://gullfoss2.fcc.gov/prod/ecfs/retrieve.cgi?native_or_pdf=pdf&id_document=7020037047