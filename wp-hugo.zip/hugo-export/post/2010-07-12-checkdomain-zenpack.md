---
title: CheckDomain Zenpack
author: Nick Anderson
type: post
date: 2010-07-12T15:52:44+00:00
url: /2010/07/12/checkdomain-zenpack/
categories:
  - Posts
tags:
  - nagios
  - sysadmin
  - zenoss
  - zenpack

---
No one likes to forget to renew a domain. Its not wholly uncommon though. [Microsoft forgot][1] to renew passport.com in 1999, and hotmail.co.uk in 2003. Vivendi Universal [forgot to renew its MP3.com][2] in 2003, the [Washington Post forgot][3] to renew in 2004, and [Foursquare forgot][4] to renew their domain in 2010.

I stumbled on the check_domain nagios plugin this weekend so I figured I would make some quick modifications and roll it into a Zenpack. You can find [ZenPacks.community.CheckDomain][5] on my github page. It has a really boreing doomsday graph included. Hope someone finds it useful.

 [1]: http://www.theregister.co.uk/2003/11/06/microsoft_forgets_to_renew_hotmail/
 [2]: http://www.theregister.co.uk/2003/10/06/day_the_music_died/
 [3]: http://news.cnet.com/2100-1025_3-5154326.html
 [4]: http://techcrunch.com/2010/03/27/foursquare-offline/
 [5]: http://github.com/nickanderson/ZenPacks.community.CheckDomain