---
title: Parable (a short allegorical story designed to illustrate or teach some truth, religious principle, or moral lesson)
author: Nick Anderson
type: post
date: 2008-11-03T21:05:18+00:00
url: /2008/11/03/parable-a-short-allegorical-story-designed-to-illustrate-or-teach-some-truth-religious-principle-or-moral-lesson/
aktt_tweeted:
  - 1
categories:
  - Posts
tags:
  - funny
  - off topic

---
Rarely do I get emails that are worthy of even reading let alone sharing with others. This one however, is pretty funny, and seems to be fairly accurate.
  
<!--more-->


  
A man in a hot air balloon realized he was lost. He reduced altitude and
  
spotted a woman below.

He descended a bit more and shouted, &#8220;Excuse me, can you help me? I promised
  
a friend I would meet him an hour ago, but I don&#8217;t know where I am&#8221;.
  
The woman below replied, &#8220;You&#8217;re in a hot air balloon hovering approximately
  
30 feet above the ground. You&#8217;re between 40 and 41 degrees north latitude
  
and between 59 and 60 degrees west longitude.&#8221;

&#8220;You must be in IT Support&#8221;, said the balloonist.

&#8220;I am&#8221;, replied the woman, &#8220;How did you know&#8221;?

&#8220;Well&#8221;, answered the balloonist, &#8220;everything you told me is technical but
  
I&#8217;ve no idea what to make of your information and the fact is I&#8217;m still
  
lost. Frankly, you&#8217;ve not been much help at all. If anything, you&#8217;ve delayed
  
my trip.&#8221;

The woman below responded, &#8220;You must be in Management&#8221;.

&#8220;I am&#8221;, replied the balloonist, &#8220;but how did you know?&#8221;

&#8220;Well&#8221;, said the woman, &#8220;you don&#8217;t know where you are or where you&#8217;re going.
  
You have risen to where you are due to a large quantity of hot air. You made
  
a promise, which you&#8217;ve no idea how to keep, and you expect people beneath
  
you to solve your problems. The fact is you are in exactly the same position
  
you were in before we met, but now, somehow, it&#8217;s all my fault.&#8221;