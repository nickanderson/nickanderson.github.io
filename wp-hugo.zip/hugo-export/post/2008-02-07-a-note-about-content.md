---
title: A note about content.
author: Nick Anderson
type: post
date: 2008-02-08T03:02:58+00:00
url: /2008/02/07/a-note-about-content/
categories:
  - Posts

---
I am pulling in a few articles from my other site which are better suited here.