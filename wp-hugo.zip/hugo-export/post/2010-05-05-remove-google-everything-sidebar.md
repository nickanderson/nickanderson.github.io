---
title: Remove Google Everything Sidebar
author: Nick Anderson
type: post
date: 2010-05-06T00:00:23+00:00
url: /2010/05/05/remove-google-everything-sidebar/
aktt_tweeted:
  - 1
categories:
  - Posts
tags:
  - google

---
Google is constantly doing experiments to see what its users like best. Today I was slapped with one of their tests, the &#8220;Everything Sidebar&#8221;. It really screwed with me and was entirely distracting while I was searching. So naturally I looked for a way to reverse it. It&#8217;s easy enough, you just need to delete a cookie.

Here is a screen shot of the results page

[<img class="aligncenter size-medium wp-image-707" title="googleleftsidebar112009" src="http://www.cmdln.org/wp-content/uploads/2010/05/googleleftsidebar112009-300x214.jpg" alt="" width="300" height="214" srcset="http://www.cmdln.org/wp-content/uploads/2010/05/googleleftsidebar112009-300x214.jpg 300w, http://www.cmdln.org/wp-content/uploads/2010/05/googleleftsidebar112009-1024x732.jpg 1024w, http://www.cmdln.org/wp-content/uploads/2010/05/googleleftsidebar112009.jpg 1200w" sizes="(max-width: 300px) 100vw, 300px" />][1]

At any rate, if you want it gone just delete the PREF cookie from google.com.

 [1]: http://www.cmdln.org/wp-content/uploads/2010/05/googleleftsidebar112009.jpg