---
title: Vmware disk recovery in linux
author: Nick Anderson
type: post
date: 2008-02-08T03:23:26+00:00
url: /2008/02/07/vmware-disk-recovery-in-linux/
categories:
  - Posts
tags:
  - recovery
  - vmware

---
If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
`If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
` 

Once you have that in your kernel you can use vmware-mount.pl to mount your vmdk disks.
   
``If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
`If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
` 

Once you have that in your kernel you can use vmware-mount.pl to mount your vmdk disks.
   
`` 

Example usage:
   
```If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
`If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
` 

Once you have that in your kernel you can use vmware-mount.pl to mount your vmdk disks.
   
``If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
`If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
` 

Once you have that in your kernel you can use vmware-mount.pl to mount your vmdk disks.
   
`` 

Example usage:
   
``` 
   
As you can see I can now recover files from my vmdk by looking in /mnt/vmware/
   
````If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
`If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
` 

Once you have that in your kernel you can use vmware-mount.pl to mount your vmdk disks.
   
``If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
`If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
` 

Once you have that in your kernel you can use vmware-mount.pl to mount your vmdk disks.
   
`` 

Example usage:
   
```If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
`If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
` 

Once you have that in your kernel you can use vmware-mount.pl to mount your vmdk disks.
   
``If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
`If you have ever had an issue with vmware or if you have been afraid of using vmware for fear that if something goes horribly wrong you may not be able to extract the information from your vmware image then this information should help you.
   
<!--more-->


   
The ability to mount a vmware image has been around for a while. To do it in linux you just need Network Block Device support in your kernel.
   
` 

Once you have that in your kernel you can use vmware-mount.pl to mount your vmdk disks.
   
`` 

Example usage:
   
``` 
   
As you can see I can now recover files from my vmdk by looking in /mnt/vmware/
   
````