---
title: About
author: Nick Anderson
type: page
date: 2008-02-07T05:09:44+00:00
aktt_notify_twitter:
  - no

---
[<img class="alignleft  wp-image-1021 qkdaioedlcduiwhxizul qkdaioedlcduiwhxizul mbadxtttaxcobhdrgtrk vaztdwshauwjdsswaohg" title="Nick Anderson" alt="Nick Anderson" src="http://www.cmdln.org/wp-content/uploads/2008/02/bw_headshot-260x300.jpg" width="234" height="270" srcset="http://www.cmdln.org/wp-content/uploads/2008/02/bw_headshot-260x300.jpg 260w, http://www.cmdln.org/wp-content/uploads/2008/02/bw_headshot.jpg 597w" sizes="(max-width: 234px) 100vw, 234px" />][1]I am probably best described as an infrastructure engineer, but I self identify as a &#8220;SysAdmin&#8221;. I like my environments to take care of themselves whenever possible. I geek out on gadgets, and usually try to avoid &#8220;Enterprise&#8221; software instead preferring open-source solutions. If Enterprise software is the right tool I&#8217;ll use it, but I probably will mutter about it mostly because of past experience with Enterprise software. I am described as a workaholic by many but I am conscious of that tendency and try to step away to keep myself sane. I am fortunate to work with very intelligent people, and generally to be getting paid for work that I would do for free (if money didn&#8217;t exist).

I am a husband and father of 2.

<pre>bundle common contact_nick_anderson
{
  vars:
      "email"    string =&gt; "nick@cmdln.org";
      "github"   string =&gt; "https://github.com/nickanderson";
      "twitter"  string =&gt; "@cmdln_";
      "blog"     string =&gt; "http://www.cmdln.org";
      "linkedin" string =&gt; "http://www.linkedin.com/in/hithisisnick";
}</pre>

 [1]: http://www.cmdln.org/wp-content/uploads/2008/02/bw_headshot.jpg