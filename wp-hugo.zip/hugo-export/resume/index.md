---
title: Resume
author: Nick Anderson
type: page
date: 2008-04-07T06:22:00+00:00
aktt_notify_twitter:
  - no
syntaxhighlighter_encoded:
  - 1

---
Although I am quite happy with my current employer, I am always open to hearing about new opportunities.

[My profile on LinkedIn][1].

 [1]: http://www.linkedin.com/in/hithisisnick